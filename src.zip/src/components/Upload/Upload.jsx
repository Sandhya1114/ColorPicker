import ColorExtractor from '../ColorExtractor/ColorExtractor';

function Upload() {
  return (
    <div>
      <h2 style={{ textAlign: 'center', margin: '20px 0' }}>Upload Image & Extract Colors</h2>
      <ColorExtractor />

    </div>
  
  );
}

export default Upload;
